#include<iostream>
using namespace std;

int main()
{
    string add= "Something";
    string a ;
    cout << "Enter the argument a ";
    getline(cin, a);
    cout << add << " " << a;
    
    return 0;
}
